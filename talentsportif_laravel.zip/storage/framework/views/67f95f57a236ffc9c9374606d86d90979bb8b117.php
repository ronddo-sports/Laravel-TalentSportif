<?php $__env->startSection('body'); ?>
    
    <div class="wrapper">
        
        <?php echo $__env->make('admin.Layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <?php echo $__env->make('admin.Layouts.sideBar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            
            
            
            <?php echo $__env->yieldContent('content'); ?>
        
        
        
        </div>
        <!-- /.content-wrapper -->
        
       <?php echo $__env->make('admin.Layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    </div>
    <!-- ./wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.Layouts.secondLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>