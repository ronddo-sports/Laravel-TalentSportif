<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->yieldContent('head'); ?>
    
    <?php echo $__env->yieldContent('styles'); ?>
    
    <?php echo $__env->yieldContent('customStyles'); ?>

</head>
<body class="hold-transition skin-blue sidebar-mini">

<?php echo $__env->yieldContent('body'); ?>

<?php echo $__env->yieldContent('scripts'); ?>

<?php echo $__env->yieldContent('customScripts'); ?>
</body>
</html>
