<?php $__env->startSection('customStyles'); ?>
    <style>
        .cropit-preview {
            background-color: #f8f8f8;
            background-size: cover;
            margin-top: 7px;
            width: 334px;
            height: 250px;
            border: 3px solid rgba(128, 128, 128, 0.34);
        
        }
    
    </style>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    
    <div style="padding: 1%;max-width: 1000px; margin: auto;">
        <div class="choix">
            Albums - <strong style="text-transform: capitalize"><?php echo e(transUpl(@$album->name)); ?></strong>
        </div>
        
        <div class="upload_image">
            <div class=" panel-info">
                
                
                <div class="panel-body">
                    
                    <div class="col-md-12">
                        <strong id="fur">Images</strong><br><br>
                        <div id="links">
                            <?php if($images != null): ?>
        
                                <div id="links" class="links" style="display: inline-block;">
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e($image->url); ?>" title="<?php echo e(@$album->name); ?> - <?php echo e($image->titre); ?>">
                                            <img src="<?php echo e($images->count() < 10 ? $image->url.'?w=150&h=110&fit=crop' : $image->url.'?w=100&h=75&fit=crop'); ?>">
                                        </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                                <?php if(Auth::check() && $album->owner_id == Auth::id() && $album->owner_table == 'users'): ?>
                                    <a href="#ajout_image"  title="Ajouter une photo" id="myBtn" style="display: inline-block">
                                        <img src="<?php echo e($images->count() < 10 ? '/img/iconAdd.png?w=150&h=110fit=crop' : '/img/iconAdd.png?w=100&h=75fit=crop'); ?>">
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <hr>
                    </div>
                    <?php if($videos != null): ?>
                    <div class="col-md-12">
                        <strong>videos</strong><br><br>
                        <div id="links">
                            
        
                                <div id="links">
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        Affichage video
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    
                </div>
            
            </div>
    
    
    
    
    
        </div>
    
    </div>


   



    <?php echo $__env->make('frontend.profile.add_image_popup', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('customScripts'); ?>
    <script>
        $(document).ready(function () {
            $('.image-editor').cropit();
            $("#myBtn").click(function(){
                $("#ajout_image").modal();
            });
        });
        $('#inpt-btn-click').on("click" , function () {
            $('#inpt-btn').click();
        });
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.Layouts.__Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>