<div class="form-group <?php echo e($errors->has('url') ? 'has-error' : ''); ?>">
    <?php echo Form::label('url', 'Url', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('url', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('url', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('duree') ? 'has-error' : ''); ?>">
    <?php echo Form::label('duree', 'Duree', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('duree', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('duree', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('media_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('media_id', 'Media Id', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('media_id', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('media_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
