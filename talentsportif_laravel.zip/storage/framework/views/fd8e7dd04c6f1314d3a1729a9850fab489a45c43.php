<?php 
if (!isset($msg)){
 $msg = 'Page Not Found';
}
 ?>
        <?php $__env->startSection('head'); ?>
            <meta charset="utf-8">
            <title><?php echo e(trans('http.404.title')); ?></title>
            <meta name="viewport" content="width=device-width, initial-scale=1">

        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('content'); ?>
<div class="container">
    <br><br><br><br><br>
    <h3>Sorry the page you requested could not be found</h3>
    <h2>Error 404 : <?php echo e($msg); ?></h2>
</div>



<?php $__env->stopSection(); ?>
<!-- IE needs 512+ bytes: http://blogs.msdn.com/b/ieinternals/archive/2010/08/19/http-error-pages-in-internet-explorer.aspx -->
<?php echo $__env->make('frontend.Layouts.__Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>