<?php $__env->startSection('content'); ?>
<div class="one_colum">
    <div class="row">
    
    <ul id="status">
        <?php $__currentLoopData = \App\Model\UserStatus::where('enabled','=',true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $statu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form method="post" id="form<?php echo e($key); ?>" action="<?php echo e(route('ragister.step.1')); ?>">
                <input type="hidden" name="status" value="<?php echo e($statu->id); ?>">
                <li><a href="<?php echo e(url('register/'.$statu->id  )); ?>" > <img src="<?php echo e($statu->logo_url); ?>?w=591&h=402&fit=crop"><span> <?php echo e($statu->nom); ?> </span></a></li>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
</div>
    <script>
       function stepOut(formi){
           document.getElementById('#' + formi).submit();
           //formi.submit();
       }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.Layouts._Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>