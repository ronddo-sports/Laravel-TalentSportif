<?php $__env->startSection('sideBarFirst'); ?>
    
    <?php echo $__env->make('frontend.Layouts.sideBars.sideBar_lecture_video', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentContainer'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div id="__main-content" class="" >
        <a href="#menu-toggle" class="onContent" id="menu-toggl">Menu <i class="fa fa-caret-right" aria-hidden="true"></i></a>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>


<!-- ./wrapper -->


<?php echo $__env->make('frontend.Layouts.secondLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>