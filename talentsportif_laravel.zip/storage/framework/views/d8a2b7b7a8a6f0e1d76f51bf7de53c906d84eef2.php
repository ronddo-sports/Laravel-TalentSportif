


<!--  End du main content place au footer -->





<footer class="main-footer">
    
    <div class="footer-top">
    
    </div>
    
    
    <div class="footer-main" id="foot-content">
        <div class="container">
            
            <div class="row">
                <div class="col-md-4">
                    
                    <div class="footer-col">
                        
                        <h4 class="footer-title">About us <span class="title-under"></span></h4>
                        
                        <div class="footer-content">
                            
                            <p>
                                <strong>Sadaka</strong> ipsum dolor sit amet, consectetur adipiscing elit. Ut at eros rutrum turpis viverra elementum semper quis ex. Donec lorem nulla, aliquam quis neque vel, maximus lacinia urna.
                            </p>
                            
                            <p>
                                ILorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at eros rutrum turpis viverra elementum semper quis ex. Donec lorem nulla, aliquam quis neque vel, maximus lacinia urna.
                            </p>
                        
                        </div>
                    
                    </div>
                
                </div>
                
                <div class="col-md-4">
                    
                    <div class="footer-col">
                        
                        <h4 class="footer-title">LAST TWEETS <span class="title-under"></span></h4>
                        
                        <div class="footer-content">
                            <ul class="tweets list-unstyled">
                                <li class="tweet">
                                    
                                    20 Surprise Eggs, Kinder Surprise Cars 2 Thomas Spongebob Disney Pixar  http://t.co/fTSazikPd4
                                
                                </li>
                                
                                <li class="tweet">
                                    
                                    20 Surprise Eggs, Kinder Surprise Cars 2 Thomas Spongebob Disney Pixar  http://t.co/fTSazikPd4
                                
                                </li>
                                
                                <li class="tweet">
                                    
                                    20 Surprise Eggs, Kinder Surprise Cars 2 Thomas Spongebob Disney Pixar  http://t.co/fTSazikPd4
                                
                                </li>
                            
                            </ul>
                        </div>
                    
                    </div>
                
                </div>
                
                
                <div class="col-md-4">
                    
                    <div class="footer-col">
                        
                        <h4 class="footer-title">Contact us <span class="title-under"></span></h4>
                        
                        <div class="footer-content">
                            
                            <div class="footer-form">
                                
                                <div class="footer-form">
                                    
                                    <form action="" class="ajax-form">
                                        
                                        <div class="form-group">
                                            <input name="name" class="form-control" placeholder="Name" required="" type="text">
                                        </div>
                                        
                                        <div class="form-group">
                                            <input name="email" class="form-control" placeholder="E-mail" required="" type="email">
                                        </div>
                                        
                                        <div class="form-group">
                                            <textarea name="message" class="form-control" placeholder="Message" required=""></textarea>
                                        </div>
                                        
                                        
                                        <div class="form-group">
                                            <input type="checkbox" checked /><span style="position: relative;left: 3%;top: -2px;">- Resevoire le TS-News</span>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-submit pull-right">Send message</button>
                                        </div>
                                    
                                    </form>
                                
                                </div>
                            
                            </div>
                        </div>
                    
                    </div>
                
                </div>
                <div class="clearfix"></div>
            
            
            
            </div>
        
        
        </div>
    
    
    </div>
    
    <div class="footer-bottom">
        
        <div class="container text-right" style="color: #fff">
            Talent Sportif @ copyrights <?php echo e(date('Y')); ?> - Proudly Powered By <a href="/" style="color: #00fbff">Tidjani</a>
        </div>
    </div>

</footer>