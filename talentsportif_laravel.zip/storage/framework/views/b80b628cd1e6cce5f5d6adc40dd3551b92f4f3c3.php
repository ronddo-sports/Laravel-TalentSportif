<div class="form-group <?php echo e($errors->has('username') ? 'has-error' : ''); ?>">
    <?php echo Form::label('username', 'Username', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('username', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('username', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('pseudo') ? 'has-error' : ''); ?>">
    <?php echo Form::label('pseudo', 'Pseudo', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('pseudo', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('pseudo', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('email', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('email', 'messenger'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('password', 'Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('password', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('confirmation_token') ? 'has-error' : ''); ?>">
    <?php echo Form::label('confirmation_token', 'Confirmation Token', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('confirmation_token', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('confirmation_token', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('date_naiss') ? 'has-error' : ''); ?>">
    <?php echo Form::label('date_naiss', 'Date Naiss', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('date_naiss', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('date_naiss', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

    
    
        
        
    

<div class="form-group <?php echo e($errors->has('discipline') ? 'has-error' : ''); ?>">
    <?php echo Form::label('discipline', 'Discipline', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('discipline', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('discipline', '<p class="help-block">:message</p>'); ?>

    </div>
</div>



<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary pull-right']); ?>

    </div>
</div>
