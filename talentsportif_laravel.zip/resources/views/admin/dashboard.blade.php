@extends('admin.Layouts.Layout')

@section('content')
<div class="container">
    <div class="row">

        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    Your application's dashboard.
                    Ce n'est pas internet
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
