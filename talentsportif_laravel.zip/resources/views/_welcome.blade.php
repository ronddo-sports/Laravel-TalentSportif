@extends('layouts.frontend.Layout')

@section('content')
    
    <div>
        <ul class="list-group">
            <li class="list-group-item">
                <div>
                    <div class="panel-body">
                        <div class="panel-more1">
                            <a href="#" class="img_vid"  style=" height: 250px; width: 300px; border: 1px hidden;display: block; background: url('http://lorempixel.com/300/200');">
                                <div class="play-vid">Lancer...</div>
                            </a>
                        </div>
                        <div class="panel-info">
                            <br>
                            <p><strong class="titre_vid">Le titre va came ici c OKLM yes tout marche</strong></p>
                            <p>9182 Lorem Ipsum<br/>
                                consectetur adipiscing elit.<br/>
                                Nullam vel lacus felis.</p>
                        </div>
                    
                    </div>
                </div>
            </li>
            <li class="list-group-item">
                <div>
                    <div class="panel-body">
                        <div class="panel-more1">
                            <a href="#" class="img_vid"  style=" height: 200px; width: 300px; border: 1px hidden;display: block; background: url('http://lorempixel.com/300/200');">
                                <div class="play-vid">Lancer...</div>
                            </a>
                        </div>
                        <div class="panel-info">
                            <br>
                            <p><strong class="titre_vid">Le titre va came ici c OKLM yes tout marche</strong></p>
                            <p>9182 Lorem Ipsum<br/>
                                consectetur adipiscing elit.<br/>
                                Nullam vel lacus felis.</p>
                        </div>
                    
                    </div>
                </div>
            </li>
            <li class="list-group-item">
                <div>
                    <div class="panel-body">
                        <div class="panel-more1">
                            <a href="#" class="img_vid"  style=" height: 200px; width: 300px; border: 1px hidden;display: block; background: url('http://lorempixel.com/300/200');">
                                <div class="play-vid">Lancer...</div>
                            </a>
                        </div>
                        <div class="panel-info">
                            <br>
                            <p><strong class="titre_vid">Le titre va came ici c OKLM yes tout marche</strong></p>
                            <p>9182 Lorem Ipsum<br/>
                                consectetur adipiscing elit.<br/>
                                Nullam vel lacus felis.</p>
                        </div>
                    
                    </div>
                </div>
            </li>
            <li class="list-group-item">
                <div>
                    <div class="panel-body">
                        <div class="panel-more1">
                            <a href="#" class="img_vid"  style=" height: 200px; width: 300px; border: 1px hidden;display: block; background: url('http://lorempixel.com/300/200');">
                                <div class="play-vid">Lancer...</div>
                            </a>
                        </div>
                        <div class="panel-info">
                            <br>
                            <p><strong class="titre_vid">Le titre va came ici c OKLM yes tout marche</strong></p>
                            <p>9182 Lorem Ipsum<br/>
                                consectetur adipiscing elit.<br/>
                                Nullam vel lacus felis.</p>
                        </div>
                    
                    </div>
                </div>
            </li>
            <li class="list-group-item">
                <div>
                    <div class="panel-body">
                        <div class="panel-more1">
                            <a href="#" class="img_vid"  style=" height: 200px; width: 300px; border: 1px hidden;display: block; background: url('http://lorempixel.com/300/200');">
                                <div class="play-vid">Lancer...</div>
                            </a>
                        </div>
                        <div class="panel-info">
                            <br>
                            <p><strong class="titre_vid">Le titre va came ici c OKLM yes tout marche</strong></p>
                            <p>9182 Lorem Ipsum<br/>
                                consectetur adipiscing elit.<br/>
                                Nullam vel lacus felis.</p>
                        </div>
                    
                    </div>
                </div>
            </li>
        </ul>
    </div>

@stop
